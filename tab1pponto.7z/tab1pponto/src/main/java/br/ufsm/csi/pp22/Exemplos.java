package br.ufsm.csi.pp22;

public class Exemplos {
    public static void main(String[] args) {
        String s1 = "lala";
        String bkp = s1;
        String s2 = "lala";
        Integer j = 10;

        System.out.println(s1 == s2);
    }

    public static void efeitoColateral(StringBuffer s, Integer i) {
        s.append("1");
        i++;
    }

}
