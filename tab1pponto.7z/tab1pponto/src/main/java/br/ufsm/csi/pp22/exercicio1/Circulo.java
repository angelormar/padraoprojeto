package br.ufsm.csi.pp22.exercicio1;

public class Circulo implements FormaGeometrica {

    private Double raio;

    public Double getRaio() {
        return raio;
    }

    public void setRaio(Double raio) {
        this.raio = raio;
    }

    @Override
    public Double getArea() {
        return Math.PI * raio * raio;
    }
}
