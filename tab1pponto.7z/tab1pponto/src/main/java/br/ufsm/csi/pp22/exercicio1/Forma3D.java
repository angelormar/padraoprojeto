package br.ufsm.csi.pp22.exercicio1;

public interface Forma3D {
    Double getVolume();
}
