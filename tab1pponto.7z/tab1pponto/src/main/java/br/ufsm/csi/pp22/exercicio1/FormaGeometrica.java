package br.ufsm.csi.pp22.exercicio1;

public interface FormaGeometrica {

    Double getArea();

}
