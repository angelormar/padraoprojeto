package br.ufsm.csi.pp22.exercicio1;

import java.util.Objects;

public class Imovel implements FormaGeometrica, Forma3D {

    private final String identificacao;
    private final String proprietario;
    private final String endereco;
    private final TipoUso tipoUso;
    private final Peca[] pecas;

    public Peca[] getPecas() {
        return pecas;
    }

    public Imovel(String identificacao,
                  String proprietario,
                  String endereco,
                  TipoUso tipoUso,
                  Peca[] pecas)
    {
        this.identificacao = identificacao;
        this.proprietario = proprietario;
        this.endereco = endereco;
        this.tipoUso = tipoUso;
        this.pecas = pecas;
    }

    @Override
    public Double getVolume() {
        double volumeTotal = 0.0;
        for (Peca p : pecas) {
            volumeTotal += p.getVolume();
        }
        return volumeTotal;
    }

    @Override
    public Double getArea() {
        double areaTotal = 0.0;
        for (Peca p : pecas) {
            areaTotal += p.getArea();
        }
        return areaTotal;
    }

    public enum TipoUso {
        RESIDENCIAL(1), COMERCIAL(2);

        TipoUso(Integer id) {
            this.id = id;
        }

        private Integer id;

        public Integer getId() {
            return id;
        }
        public static TipoUso valueOf(int i) {
            for (TipoUso tipoUso : values()) {
                if (tipoUso.id == i) return tipoUso;
            }
            return null;
        }
    }

    public String getIdentificacao() {
        return identificacao;
    }

    public String getProprietario() {
        return proprietario;
    }

    public String getEndereco() {
        return endereco;
    }

    public TipoUso getTipoUso() {
        return tipoUso;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Imovel imovel = (Imovel) o;
        return Objects.equals(identificacao, imovel.identificacao);
    }

    @Override
    public int hashCode() {
        return Objects.hash(identificacao);
    }
}
