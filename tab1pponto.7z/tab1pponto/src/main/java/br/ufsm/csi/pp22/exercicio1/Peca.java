package br.ufsm.csi.pp22.exercicio1;

public class Peca implements FormaGeometrica, Forma3D {

    private String identificacao;
    private Double peDireito;

    public String getIdentificacao() {
        return identificacao;
    }

    public void setIdentificacao(String identificacao) {
        this.identificacao = identificacao;
    }

    public Double getPeDireito() {
        return peDireito;
    }

    public void setPeDireito(Double peDireito) {
        this.peDireito = peDireito;
    }

    public FormaGeometrica[] getFormasGeometricas() {
        return formasGeometricas;
    }

    public void setFormasGeometricas(FormaGeometrica[] formasGeometricas) {
        this.formasGeometricas = formasGeometricas;
    }

    private FormaGeometrica[] formasGeometricas;

    @Override
    public Double getArea() {
        double areaTotal = 0.0;
        for (FormaGeometrica formaGeometrica : formasGeometricas) {
            areaTotal += formaGeometrica.getArea();
        }
        return areaTotal;
    }

    @Override
    public Double getVolume() {
        return getArea() * peDireito;
    }
}
