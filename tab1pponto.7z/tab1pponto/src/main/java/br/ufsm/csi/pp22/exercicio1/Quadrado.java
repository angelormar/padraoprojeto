package br.ufsm.csi.pp22.exercicio1;

public class Quadrado implements FormaGeometrica {

    private Double lado;

    public Double getLado() {
        return lado;
    }

    public void setLado(Double lado) {
        this.lado = lado;
    }

    @Override
    public Double getArea() {
        return lado * lado;
    }
}
