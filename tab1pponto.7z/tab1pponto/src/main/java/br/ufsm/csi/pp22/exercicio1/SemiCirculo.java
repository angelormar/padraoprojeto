package br.ufsm.csi.pp22.exercicio1;

public class SemiCirculo implements FormaGeometrica {

    private Double raio;
    private Double anguloGraus;

    public Double getRaio() {
        return raio;
    }

    public void setRaio(Double raio) {
        this.raio = raio;
    }

    public Double getAnguloGraus() {
        return anguloGraus;
    }

    public void setAnguloGraus(Double anguloGraus) {
        this.anguloGraus = anguloGraus;
    }

    @Override
    public Double getArea() {
        return Math.PI * raio * raio * (anguloGraus / 360.0);
    }
}
