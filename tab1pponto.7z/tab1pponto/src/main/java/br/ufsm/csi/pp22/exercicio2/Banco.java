package br.ufsm.csi.pp22.exercicio2;

public class Banco implements BancoInterface {

    private Long NUM_CONTA = 0l;
    private String nome;
    private Long codigoBacen;
    private ContaBancaria[] contasBancarias = new ContaBancaria[0];

    public Banco(String banco_teste) {
    }

    public Banco() {
    }


    @Override
    public void criaConta(ContaBancaria contaBancaria) {
        contaBancaria.setNumero(++NUM_CONTA);
        for (int i = 0; i < contasBancarias.length; i++) {
            if (contasBancarias[i] == null) {
                contasBancarias[i] = contaBancaria;
                return;
            }
        }
        ContaBancaria[] arrNovo = new ContaBancaria[contasBancarias.length + 1];
        System.arraycopy(contasBancarias, 0, arrNovo, 0, contasBancarias.length);
        arrNovo[contasBancarias.length] = contaBancaria;
        this.contasBancarias = arrNovo;
    }

    @Override
    public boolean removeConta(ContaBancaria contaBancaria) {
        for (int i = 0; i < contasBancarias.length; i++) {
            if (contasBancarias[i].getNumero().equals(contaBancaria.getNumero())) {
                contasBancarias[i] = null;
                return true;
            }
        }
        return false;
    }

    private ContaBancaria findConta(Long numero) {
        for (ContaBancaria conta : contasBancarias) {
            if (conta.getNumero().equals(numero)) return conta;
        }
        return null;
    }

    @Override
    public boolean saque(Long numero, Double valor) {
        ContaBancaria conta = findConta(numero);
        if (conta != null) {
            Movimentacao movimentacao = new Movimentacao("saque",
                    Movimentacao.TipoMovimentacao.DEBITO,
                    -valor);
            return conta.processaMovimentacao(movimentacao);
        }
        return false;
    }

    @Override
    public boolean deposito(Long numero, Double valor) {
        ContaBancaria conta = findConta(numero);
        if (conta != null) {
            Movimentacao movimentacao = new Movimentacao("saque",
                    Movimentacao.TipoMovimentacao.CREDITO,
                    valor);
            return conta.processaMovimentacao(movimentacao);
        }
        return false;
    }

    @Override
    public Double getSaldo(Long numero) {
        ContaBancaria conta = findConta(numero);
        if (conta != null) {
            return conta.getSaldo();
        }
        return null;
    }

    @Override
    public ContaBancaria[] getContasBancarias() {
        return contasBancarias;
    }
}
