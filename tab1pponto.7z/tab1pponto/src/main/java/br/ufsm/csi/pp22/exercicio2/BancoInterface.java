package br.ufsm.csi.pp22.exercicio2;

import java.lang.reflect.InvocationTargetException;

public interface BancoInterface {
    void criaConta(ContaBancaria contaBancaria) throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException;

    boolean removeConta(ContaBancaria contaBancaria) throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException;

    boolean saque(Long numero, Double valor) throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException;

    boolean deposito(Long numero, Double valor) throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException;

    Double getSaldo(Long numero) throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException;

    ContaBancaria[] getContasBancarias();
}
