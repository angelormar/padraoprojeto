package br.ufsm.csi.pp22.exercicio2;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;


public class BancoObserver implements BancoInterface {



    private Map<Long, ContaBancaria> contasBancarias = new TreeMap<>();
    static ArrayList<Object> subscribers = new ArrayList<>();

    public BancoObserver(String banco_teste) {
    }

    static public void subscribe(Object obj){
        subscribers.add(obj);
    }

    public void notify(Object data) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        for (Object o : subscribers){
            Class c = o.getClass();
            Method[] ms = c.getDeclaredMethods();
            for(Method m: ms){
                if(m.getName().equals("update")){
                    m.invoke(data);
                }
            }
           //m.invoke(o, data);
        }
    };

    @Override
    public void criaConta(ContaBancaria contaBancaria) throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {
      notify(this);
      new Banco().criaConta(contaBancaria);
    }

    @Override
    public boolean removeConta(ContaBancaria contaBancaria) throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {

        notify(this);
        return new Banco().removeConta(contaBancaria);
    }

    @Override
    public boolean saque(Long numero, Double valor) throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {

        notify(this);
        return new Banco().saque(numero, valor);
    }

    @Override
    public boolean deposito(Long numero, Double valor) throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {

        notify(this);
        return new Banco().deposito(numero, valor);
    }

    @Override
    public Double getSaldo(Long numero) throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {
        notify(this);
        return new Banco().getSaldo(numero);
    }

    @Override
    public ContaBancaria[] getContasBancarias() {
        return new Banco().getContasBancarias();
    }


}
