package br.ufsm.csi.pp22.exercicio2;

import java.util.Objects;

public abstract class ContaBancaria extends Subscribers {

    public enum TipoContaBancaria { CONTA_CORRENTE,
        FUNDO_RENDA_FIXA, FUNDO_RENDA_VARIAVEL, POUPANCA }

    private Long numero;
    private Double saldo;
    private Movimentacao[] movimentacoes;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ContaBancaria that = (ContaBancaria) o;
        return Objects.equals(numero, that.numero);
    }

    public ContaBancaria() {
        BancoObserver.subscribe(this);
    }

    public abstract boolean processaMovimentacao(Movimentacao movimentacao);

    @Override
    public int hashCode() {
        return Objects.hash(numero);
    }

    public Long getNumero() {
        return numero;
    }

    public void setNumero(Long numero) {
        this.numero = numero;
    }

    public Double getSaldo() {
        return saldo;
    }

    public void setSaldo(Double saldo) {
        this.saldo = saldo;
    }

    public Movimentacao[] getMovimentacoes() {
        return movimentacoes;
    }

    public void setMovimentacoes(Movimentacao[] movimentacoes) {
        this.movimentacoes = movimentacoes;
    }

    protected void adicionaMovimentacao(Movimentacao movimentacao) {
        setSaldo(getSaldo() + movimentacao.getValor());
        Movimentacao[] arrNovo = new Movimentacao[getMovimentacoes().length + 1];
        System.arraycopy(getMovimentacoes(), 0, arrNovo, 0, getMovimentacoes().length);
        arrNovo[getMovimentacoes().length] = movimentacao;
        setMovimentacoes(arrNovo);
    }

    public abstract Double calculaIRDevido();

}
