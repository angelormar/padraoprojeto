package br.ufsm.csi.pp22.exercicio2;

public class ContaCorrente extends ContaBancaria {

    @Override
    public void update(Object context){  }

    private boolean especial;
    private Double limite;

    public boolean isEspecial() {
        return especial;
    }

    public void setEspecial(boolean especial) {
        this.especial = especial;
    }

    public Double getLimite() {
        return limite;
    }

    public void setLimite(Double limite) {
        this.limite = limite;
    }

    @Override
    public boolean processaMovimentacao(Movimentacao movimentacao) {
        double limiteSaque = (especial ? getSaldo() + getLimite() : getSaldo());
        if (movimentacao.getTipoMovimentacao() == Movimentacao.TipoMovimentacao.DEBITO
                && Math.abs(movimentacao.getValor()) > limiteSaque
        ) {
            return false;
        }
        adicionaMovimentacao(movimentacao);
        return true;
    }

    @Override
    public Double calculaIRDevido() {
        return 0.0;
    }


}
