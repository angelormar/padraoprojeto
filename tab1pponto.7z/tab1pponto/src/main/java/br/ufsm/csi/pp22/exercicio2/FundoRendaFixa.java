package br.ufsm.csi.pp22.exercicio2;

public class FundoRendaFixa extends ContaBancaria {

    @Override
    public boolean processaMovimentacao(Movimentacao movimentacao) {
        if (movimentacao.getTipoMovimentacao() == Movimentacao.TipoMovimentacao.DEBITO
                && Math.abs(movimentacao.getValor()) > getSaldo()
        ) {
            return false;
        }
        adicionaMovimentacao(movimentacao);
        return true;
    }

    @Override
    public Double calculaIRDevido() {
        double ir = 0.0;
        for (Movimentacao movimentacao : getMovimentacoes()) {
            if (movimentacao.getTipoMovimentacao() == Movimentacao.TipoMovimentacao.RENDIMENTO_FINANCEIRO) {
                ir += movimentacao.getValor() * 0.275;
            }
        }
        return ir;
    }

}
