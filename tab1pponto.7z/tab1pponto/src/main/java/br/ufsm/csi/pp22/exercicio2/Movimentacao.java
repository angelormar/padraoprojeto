package br.ufsm.csi.pp22.exercicio2;

public class Movimentacao {

    private String descricao;
    private TipoMovimentacao tipoMovimentacao;
    private Double valor;

    public enum TipoMovimentacao {
        CREDITO, DEBITO, RENDIMENTO_FINANCEIRO
    }

    public Movimentacao() { }

    public Movimentacao(String descricao, TipoMovimentacao tipoMovimentacao, Double valor) {
        this.descricao = descricao;
        this.tipoMovimentacao = tipoMovimentacao;
        this.valor = valor;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public TipoMovimentacao getTipoMovimentacao() {
        return tipoMovimentacao;
    }

    public void setTipoMovimentacao(TipoMovimentacao tipoMovimentacao) {
        this.tipoMovimentacao = tipoMovimentacao;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }
}
