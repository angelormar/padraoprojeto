package br.ufsm.csi.pp22.exercicio2;

public class Poupanca extends ContaBancaria {
    @Override
    public boolean processaMovimentacao(Movimentacao movimentacao) {
        if (movimentacao.getTipoMovimentacao() == Movimentacao.TipoMovimentacao.DEBITO
                && Math.abs(movimentacao.getValor()) > getSaldo()
        ) {
            return false;
        }
        adicionaMovimentacao(movimentacao);
        return true;
    }

    @Override
    public Double calculaIRDevido() {
        return 0.0;
    }

}
