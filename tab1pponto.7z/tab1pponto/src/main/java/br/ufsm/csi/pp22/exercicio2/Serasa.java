package br.ufsm.csi.pp22.exercicio2;

import java.util.ArrayList;

public class Serasa {

    static ArrayList<Long> contasNoSerasa = new ArrayList<>();


}
