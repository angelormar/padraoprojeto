package br.ufsm.csi.pp22.exercicio2;

public class Subscribers {

    void update(Object context){};

}
