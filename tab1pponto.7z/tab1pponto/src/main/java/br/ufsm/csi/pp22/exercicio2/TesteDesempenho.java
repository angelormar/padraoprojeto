package br.ufsm.csi.pp22.exercicio2;



import java.lang.reflect.InvocationTargetException;
import java.util.Map;

public class TesteDesempenho {

    public static void main(String[] args) throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {
        BancoObserver banco = new BancoObserver("Banco Teste");
        long time = System.currentTimeMillis();
        for (int i = 0; i < 100; i++) {
            ContaCorrente conta = new ContaCorrente();
            conta.setEspecial(true);
            conta.setLimite(200.0);
            banco.criaConta(conta);
        }
        System.out.println("Tempo decorrido insercao: " + (System.currentTimeMillis() - time) + "ms");
        time = System.currentTimeMillis();
        for ( ContaBancaria b : banco.getContasBancarias()){
            System.out.println((b.getSaldo()));
        }
        System.out.println("Tempo decorrido busca: " + (System.currentTimeMillis() - time) + "ms");
    }

}
