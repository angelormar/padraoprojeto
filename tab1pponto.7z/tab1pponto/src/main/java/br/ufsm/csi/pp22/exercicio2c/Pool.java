package br.ufsm.csi.pp22.exercicio2c;

import java.lang.reflect.InvocationTargetException;

public interface Pool<T> {

    T acquire() throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException;
    void release(T t);

}
