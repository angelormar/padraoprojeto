package br.ufsm.csi.pp22.exercicio3;

import br.ufsm.csi.pp22.exercicio6.MinhaAnnotation;

import java.util.Map;
import java.util.TreeMap;

public class Banco {

    private Long NUM_CONTA = 0l;
    private String nome;
    private Long codigoBacen;
    private Map<Long, ContaBancaria> contasBancarias = new TreeMap<>();

    public Banco() { }

    public Banco(String nome) {
        this.nome = nome;
    }

    @MinhaAnnotation(nome = "lala")
    public void criaConta(ContaBancaria contaBancaria) {
        contaBancaria.setNumero(++NUM_CONTA);
        contasBancarias.put(contaBancaria.getNumero(), contaBancaria);
    }

    @MinhaAnnotation
    public boolean removeConta(ContaBancaria contaBancaria) {
        return contasBancarias.remove(contaBancaria.getNumero()) != null;
    }

    public boolean saque(Long numero, Double valor) {
        ContaBancaria conta = contasBancarias.get(numero);
        if (conta != null) {
            Movimentacao movimentacao = new Movimentacao("saque",
                    Movimentacao.TipoMovimentacao.DEBITO,
                    -valor);
            return conta.processaMovimentacao(movimentacao);
        }
        return false;
    }

    public boolean deposito(Long numero, Double valor) {
        ContaBancaria conta = contasBancarias.get(numero);
        if (conta != null) {
            Movimentacao movimentacao = new Movimentacao("saque",
                    Movimentacao.TipoMovimentacao.CREDITO,
                    valor);
            return conta.processaMovimentacao(movimentacao);
        }
        return false;
    }

    public Double getSaldo(Long numero) {
        ContaBancaria conta = contasBancarias.get(numero);
        if (conta != null) {
            return conta.getSaldo();
        }
        return null;
    }

    public Map<Long, ContaBancaria> getContasBancarias() {
        return contasBancarias;
    }
}
