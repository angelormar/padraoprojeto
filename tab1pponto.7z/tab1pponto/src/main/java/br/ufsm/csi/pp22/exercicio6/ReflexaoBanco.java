package br.ufsm.csi.pp22.exercicio6;

import br.ufsm.csi.pp22.exercicio3.Banco;
import br.ufsm.csi.pp22.exercicio3.ContaBancaria;

import javax.swing.*;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Enumeration;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public class ReflexaoBanco {

    public ReflexaoBanco() {
    }

    public static void main(String[] args) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException, IOException, ClassNotFoundException {
        JFileChooser jfc = new JFileChooser(new File("C:\\Users\\professor\\IdeaProjects\\pp-exemplos-2022\\target\\"));
        int returnValue = jfc.showOpenDialog(new JFrame());
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFile = jfc.getSelectedFile();
            JarFile jarFile = new JarFile(selectedFile);
            Enumeration<JarEntry> ent = jarFile.entries();
            URL url = selectedFile.toURI().toURL();
            URLClassLoader child = new URLClassLoader(
                    new URL[] { url },
                    ReflexaoBanco.class.getClassLoader()
            );
            while (ent.hasMoreElements()) {
                JarEntry jarEntry = ent.nextElement();
                if (jarEntry.getName().endsWith(".class")) {
                    String classname = jarEntry.getName().replace("/", ".").replace(".class", "");
                    Class classe = Class.forName(classname, true, child);
                    printInfos(classe);
                }
            }
        }


    }

    private static void printInfos(Class classe) throws InvocationTargetException, IllegalAccessException, NoSuchMethodException, InstantiationException {
        //Object obj = classe.getDeclaredConstructor().newInstance();
        System.out.println("\n\n -------------------Reflexão na classe " + classe.getName() + "");
        for (Field campo : classe.getDeclaredFields()) {
            String fin = Modifier.isFinal(campo.getModifiers()) ? "final " : "";
            String priv = Modifier.isPrivate(campo.getModifiers()) ? "private " : "";
            String pub = Modifier.isPublic(campo.getModifiers()) ? "public " : "";
            String stat = Modifier.isStatic(campo.getModifiers()) ? "static " : "";
            System.out.println("<CAMPO> " + pub + priv + stat + fin + campo.getType().getSimpleName() + " " +
                    campo.getName());
        }
        for (Method metodo : classe.getDeclaredMethods()) {
            String fin = Modifier.isFinal(metodo.getModifiers()) ? "final " : "";
            String priv = Modifier.isPrivate(metodo.getModifiers()) ? "private " : "";
            String pub = Modifier.isPublic(metodo.getModifiers()) ? "public " : "";
            String stat = Modifier.isStatic(metodo.getModifiers()) ? "static " : "";
            StringBuilder sb = new StringBuilder();
            for (Class tipoParam : metodo.getParameterTypes()) {
                if (!sb.isEmpty()) {
                    sb.append(", ");
                }
                sb.append(tipoParam.getSimpleName());
            }
            if (metodo.getAnnotation(MinhaAnnotation.class) != null) {
                MinhaAnnotation annot = metodo.getAnnotation(MinhaAnnotation.class);

                System.out.println("<METODO> <"+ annot.nome() + "> " + pub + priv + stat + fin + metodo.getReturnType().getSimpleName() + " " +
                        metodo.getName() + "(" + sb + ")");
            }
//            if (sb.isEmpty()) {
//                Object ret = metodo.invoke(obj);
//                System.out.println("   --> " + ret.getClass().getSimpleName() + " " + ret);
//            }
        }
    }

}
