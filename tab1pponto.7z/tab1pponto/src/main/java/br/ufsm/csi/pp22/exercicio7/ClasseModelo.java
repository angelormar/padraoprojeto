package br.ufsm.csi.pp22.exercicio7;

import java.util.Date;
import java.util.Objects;

public class ClasseModelo {

    private Integer id;
    private String nome;
    private String endereco;

    private String[] array;

    private OutraClasse outraClasse;

    @JSON(recursive = true)
    public OutraClasse getOutraClasse() {
        return outraClasse;
    }

    public void setOutraClasse(OutraClasse outraClasse) {
        this.outraClasse = outraClasse;
    }

    @JSON
    public String[] getArray() {
        return array;
    }

    public void setArray(String[] array) {
        this.array = array;
    }

    @JSON(dateFormat = "yyyy-MM-dd")
    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    private Date data;

    @JSON
    public boolean isValido() {
        return valido;
    }

    public void setValido(boolean valido) {
        this.valido = valido;
    }

    private boolean valido;

    @JSON
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @JSON
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @JSON
    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClasseModelo that = (ClasseModelo) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public static class OutraClasse {

        public OutraClasse(String prop1, String prop2) {
            this.prop1 = prop1;
            this.prop2 = prop2;
        }

        private String prop1;
        private String prop2;

        @JSON
        public String getProp1() {
            return prop1;
        }

        @JSON
        public void setProp1(String prop1) {
            this.prop1 = prop1;
        }

        public String getProp2() {
            return prop2;
        }

        public void setProp2(String prop2) {
            this.prop2 = prop2;
        }
    }

}
