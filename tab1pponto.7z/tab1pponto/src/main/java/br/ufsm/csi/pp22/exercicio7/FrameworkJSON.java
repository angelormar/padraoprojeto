package br.ufsm.csi.pp22.exercicio7;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FrameworkJSON {

    public static void main(String[] args) throws InvocationTargetException, IllegalAccessException {
        ClasseModelo modelo = new ClasseModelo();
        modelo.setEndereco("algum endereco");
        modelo.setId(1);
        modelo.setNome("algum nome");
        modelo.setValido(true);
        modelo.setData(new Date());
        modelo.setArray(new String[] { "a", "b", "c" });
        modelo.setOutraClasse(new ClasseModelo.OutraClasse("p1", "p2"));
        System.out.println(new FrameworkJSON().getJSON(modelo));
    }

    public String getJSON(Object o) throws InvocationTargetException, IllegalAccessException {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        boolean primeiro = true;
        for (Method method : o.getClass().getDeclaredMethods()) {
            if ((method.getName().startsWith("get") || method.getName().startsWith("is"))
                && method.getAnnotation(JSON.class) != null
                && method.getParameterCount() == 0)
            {
                if (!primeiro) {
                    sb.append(",\n");
                } else {
                    primeiro = false;
                }
                String nomePropriedade = method.getName().replace("get", "").replace("is", "");
                nomePropriedade = nomePropriedade.substring(0, 1).toLowerCase() + nomePropriedade.substring(1);
                Object valor = method.invoke(o);
                String strValor;
                int i = 0;
                Integer i2 = 0;
                if (valor.getClass().isArray()) {
                    Object[] arrValor = (Object[]) valor;
                    StringBuilder sbArr = new StringBuilder();
                    sbArr.append("[");
                    boolean primeiroArray = true;
                    for (Object vlr : arrValor) {
                        if (!primeiroArray) {
                            sbArr.append(", ");
                        } else {
                            primeiroArray = false;
                        }
                        sbArr.append(getStrValor(vlr, method));
                    }
                    strValor = sbArr.append("]").toString();
                } else {
                    strValor = getStrValor(valor, method);
                }

                sb.append("\t\"" + nomePropriedade + "\": " + strValor);
            }
        }
        sb.append("\n}");
        return sb.toString();
    }

    private String getStrValor(Object valor, Method method) throws InvocationTargetException, IllegalAccessException {
        String valorStr = "";
        JSON anot = method.getAnnotation(JSON.class);
        if (!anot.dateFormat().isEmpty()) {
            SimpleDateFormat sdf = new SimpleDateFormat(anot.dateFormat());
            if (!Date.class.isAssignableFrom(valor.getClass())) {
                throw new IllegalArgumentException("dateFormat informado para a propriedade que não é do " +
                        "tipo java.util.Date.");
            }
            valorStr = "\"" + sdf.format(valor) + "\"";
        } else if (Number.class.isAssignableFrom(valor.getClass())
                || Boolean.class.isAssignableFrom(valor.getClass())) {
            valorStr = valor.toString();
        } else {
            valorStr = "\"" + valor + "\"";
        }
        return valorStr;
    }

}
